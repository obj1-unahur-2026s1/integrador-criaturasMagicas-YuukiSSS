class Mascota{
    var edad = 10
    var tieneCuernos = true
    method esVeterana() = edad >= 10
    method tieneCuernos() = tieneCuernos
}