class Colonia{
    const criaturas = []
    method poderOfensivo() = criaturas.sum({c => c.poderOfensivo()})
    method cantidadFormidables() = criaturas.count({c => c.esFormidable()})
    method conquistarArea(area){
        if(area.poderDefensivo() < self.poderOfensivo()){
            area.cambiarColoniaQueLaDomina(self)
        }
        else{
            self.sufrirDerrota()
        }
    }
    method sufrirDerrota() {
        criaturas.forEach({c => c.variacionDerrota()})
    }

}