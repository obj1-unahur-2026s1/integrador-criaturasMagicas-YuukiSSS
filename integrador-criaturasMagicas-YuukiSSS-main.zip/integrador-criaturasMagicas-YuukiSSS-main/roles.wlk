
import mascotas.*
object guardian{
    method extra() = 100
    method esExtraordinario(criatura) = criatura.poderOfensivo() > 50
    method siguienteRol() = new Domador(mascotas = [new Mascota(edad = 1, tieneCuernos = false)])
}
object hechicero{
    method extra() {}
    method esExtraordinario() = true
    method siguienteRol() = guardian
}
class Domador{
    const mascotas = []
    method extra() = 150 * self.cantidadMascotasConCuernos()
    method cantidadMascotasConCuernos() = mascotas.count({p => p.tieneCuernos()})
    
    method esExtraordinario(criatura) = criatura.poderMagico() >= 15 and mascotas.all({p => p.esVeterana()})
    method siguienteRol(){
            if(self.cantidadMascotasConCuernos() > 0){
                return hechicero
            }
            else{
                self.error("No se puede cambiar de rol, no tiene mascotas con cuernos")
            }
    }
}