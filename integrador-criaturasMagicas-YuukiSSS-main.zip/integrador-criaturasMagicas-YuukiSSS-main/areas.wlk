class Area{
    var coloniaQueLaDomina
    method poderDefensivo()
    method cambiarColoniaQueLaDomina(nuevaColonia) { coloniaQueLaDomina = nuevaColonia }
}
class Claro inherits Area{
    override method poderDefensivo() = 100 + coloniaQueLaDomina.poderOfensivo()
}
class Castillo inherits Area{
    override method poderDefensivo() = 200 * coloniaQueLaDomina.cantidadFormidables()
}