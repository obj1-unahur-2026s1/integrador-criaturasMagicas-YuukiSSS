class Criatura{
    var poderMagico
    const astucia
    var rol
    
    method poderMagico() = poderMagico
    method poderOfensivo() = poderMagico * 10 + rol.extra()
    method esAstuta()
    method esExtraordinaria() = rol.esExtraordinario(self)
    method esFormidable() = self.esAstuta() or self.esExtraordinaria()
    method cambiarRol(nuevoRol) { rol = rol.siguienteRol() }
    method variacionDerrota() { poderMagico = poderMagico * 0.15 }
}
class Duende inherits Criatura{
    override method poderOfensivo() = super() * 1.1
    override method esAstuta() = false
}
class Hada inherits Criatura{
    var kmPuedeVolar = 2
    method agregarKmPuedeVolar(km) { kmPuedeVolar = (kmPuedeVolar + km).min(25) }
    override method esAstuta() = astucia > 50
    override method esExtraordinaria() = super() and kmPuedeVolar > 10
    
}